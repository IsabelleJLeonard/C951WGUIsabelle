WGU C195 Software 2, GUI-based Java Application
Author: Isabelle Matthews Contact: imatt12@wgu.edu Application Version: 8.0 Date: May 19, 2022

IDE: Intellij Community Edition 2021.01.3 x64
JDK: Java version 17.0.1
JAVAFX: JAVAFX.SDK.11.0.2

-directions how to run program, (ex; launch application, log in)

-In the report, 3rd table is reporting Country and Customer. The report will display which country and how many customer in each Country in two columns.

mySQL version: mySQL-connector-java-8.0.25
