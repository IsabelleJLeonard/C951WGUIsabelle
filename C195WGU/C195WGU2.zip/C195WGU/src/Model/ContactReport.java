package Model;

public class ContactReport {

}
