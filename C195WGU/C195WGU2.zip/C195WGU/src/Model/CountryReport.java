package Model;
/*
@author Isabelle Matthews
 */

public class CountryReport {
    private String countryName;
    private int customerTotal;

    public CountryReport(String countryName, int customerTotal) {
        this.countryName = countryName;
        this.customerTotal = customerTotal;
    }

    //Country
    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    //Customer total
    public int getCustomerTotal() {
        return customerTotal;
    }

    public void setCustomerTotal(int customerTotal) {
        this.customerTotal = customerTotal;
    }
}
