package Model;

/*
@author Isabelle Matthews
 */

public class AppointmentReport {
    private int appointmentTotal;
    private String type;
    private int month;

    //get appointment total
    public int getAppointmentTotal() {
        return appointmentTotal;
    }

    public void setAppointmentTotal(int appointmentTotal) {
        this.appointmentTotal = appointmentTotal;
    }

    //type
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    //month
    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public AppointmentReport(String type, int month, int appointmentTotal) {
        this.type = type;
        this.month = month;
        this.appointmentTotal = appointmentTotal;

    }
}
