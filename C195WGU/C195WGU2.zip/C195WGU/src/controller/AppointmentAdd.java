package controller;

/**
 * ADD controller for appointment table.
 * @author Isabelle Matthews
 */

import Model.Appointment;
import Model.Contact;
import Model.Customer;
import Model.user;
import database.AppointmentData;
import database.ContactData;
import database.CustomerData;
import database.UserData;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class AppointmentAdd implements Initializable {
    public TextField appointmentID;
    public TextField title;
    public TextField description;
    public TextField location;
    public ComboBox<Contact> contactAdd;
    public TextField type;
    public TextField start;
    public TextField end;
    public ComboBox<Model.user> user;
    public ComboBox<Customer> customer;
    public Button saveButton;
    public Button cancelButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customer.setItems(CustomerData.getAllCustomers());
        user.setItems(UserData.getAllUsers());
        contactAdd.setItems(ContactData.getAllContact());

    }

    //save APPOINTMENT
    public void saveButton(ActionEvent actionEvent) throws SQLException, IOException {
        // move error before SAVE, so it can check errors without saving error information after alert.
        if (title.getText().trim().isEmpty() || title.getText().trim().toLowerCase().equals("Title")) {
            AlertMessage.error(5, title);
            return;
        }
        if (description.getText().trim().isEmpty() || description.getText().trim().toLowerCase().equals("Description")) {
            AlertMessage.error(6, description);
            return;
        }
        if (type.getText().trim().isEmpty() || type.getText().trim().toLowerCase().equals("Type")) {
            AlertMessage.error(7, type);
            return;
        }
        if (location.getText().trim().isEmpty() || location.getText().trim().toLowerCase().equals("Location")) {
            AlertMessage.error(8,location);
            return;
        }
        if (contactAdd.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText("must select contact");
            alert.showAndWait();
            return;
        }
        if (user.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText("must select user");
            alert.showAndWait();
            return;
        }
        if (customer.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText("must select customer");
            alert.showAndWait();
            return;
        }

        //overlap appointment
       /* try {
           ObservableList<Appointment> appointments = AppointmentData.getCustomerAppointment();

           LocalDateTime startAppt = LocalDateTime.of();
           LocalDateTime endAppt = LocalDateTime.of();
           LocalDateTime currentStart = LocalDateTime.of();
           LocalDateTime currentEnd = LocalDateTime.of();

           if (currentStart.equals(startAppt) || currentEnd.equals(endAppt)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Appointment time is overlapping, please check again");
               alert.showAndWait();
               return;
           }
           if (currentStart.isBefore(startAppt) && currentEnd.isAfter(startAppt)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Appointment time is overlapping, please check again");
               alert.showAndWait();
               return;
           }
           if (currentStart.isAfter(startAppt) && currentStart.isBefore(endAppt)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Appointment time is overlapping, please check again");
               alert.showAndWait();
               return;
           }
           if (currentStart.isBefore(startAppt) && currentEnd.isAfter(startAppt)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Appointment time is overlapping, please check again");
               alert.showAndWait();
               return;
           }
           if (currentStart.isAfter(startAppt) && currentEnd.isBefore(startAppt)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Appointment time is overlapping, please check again");
               alert.showAndWait();
               return;
           }
           if (currentStart.isBefore(startAppt) && currentEnd.equals(endAppt)) {
               System.out.println("No overlaps");
           }
           if (currentStart.equals(endAppt) && currentEnd.isBefore(endAppt)) {
               System.out.println("No overlaps");
           } else
               System.out.println("No overlaps");
       } catch (Exception e) {
           e.printStackTrace();
       } */

        String Title = title.getText();
        String Description = description.getText();
        String Type = type.getText();
        String Location = location.getText();
        String Start = start.getText();
        String End = end.getText();
        int Contact = (contactAdd.getValue().getContactID());
        int User = (user.getValue().getUserID());
        int Customer = (customer.getValue().getCustomer_ID());
        AppointmentData.addAppointment(Title, Description, Type, Location, Start, End, Contact, User, Customer);

        Parent root = FXMLLoader.load(getClass().getResource("/view/Scheduling.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 900, 600);
        stage.setTitle("Appointment");
        stage.setScene(scene);
    }

    // go back to appointment schedule.
    public void backButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/Scheduling.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 900, 600);
        stage.setTitle("Appointment");
        stage.setScene(scene);
    }
}
