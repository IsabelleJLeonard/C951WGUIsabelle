package controller;

/**
 * Customer Update Controller
 * @author Isabelle Matthews
 */

import Model.Country;
import Model.Customer;
import Model.Division;
import database.CountryData;
import database.CustomerData;
import database.DivisionData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CustomerUpdate implements Initializable {

   // private static Customer editCustomer;
    @FXML public TextField customerID;
    @FXML public TextField customerName;
    @FXML public TextField country;
    @FXML public TextField address;
    @FXML public TextField phone;
    @FXML public TextField postalCode;
    @FXML public ComboBox<Division> divisionCombo;
    @FXML public ComboBox<Country> countryCombo;
    @FXML public Button updateCustomer;
    @FXML public Button cancelButton;

   // public static void editCustomer(Customer customer) { customer = customer; }
    ObservableList<DivisionData> divisionList = FXCollections.observableArrayList();
    ObservableList<CountryData> countryList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        countryCombo.setItems(CountryData.getAllCountries());
    }


    //CANCEL BUTTON
    public void cancelButton(ActionEvent actionEvent) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/view/SecondScreen.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 900, 500);
            stage.setTitle("Customer List");
            stage.setScene(scene);
        }


    //UPDATE CUSTOMER INFORMATION AND GO BACK TO CUSTOMER TABLE
    public void updateCustomer(ActionEvent actionEvent) throws IOException, SQLException {
        try {
            int customer_ID = Integer.parseInt(customerID.getText());
            String customer_Name = customerName.getText();
            String Address = address.getText();
            String phoneNum = phone.getText();
            String postal_Code = postalCode.getText();
            int countryID = (countryCombo.getValue().getCountryId());
            int divisionID = (divisionCombo.getValue().getDivisionID());
            CustomerData.updateCustomer(customer_ID, customer_Name, Address, phoneNum, postal_Code, countryID, divisionID);

            if (customerName.getText().trim().isEmpty() || customerName.getText().trim().toLowerCase().equals("customer name")) {
                AlertMessage.error(4, customerName);
                return;
            }
            if (address.getText().trim().isEmpty() || address.getText().trim().toLowerCase().equals("address")) {
                    AlertMessage.error(3, address);
                    return;
            }
            if (phone.getText().trim().isEmpty() || phone.getText().trim().toLowerCase().equals("phone")) {
                AlertMessage.error(2, phone);
                return;
            }
            if (postalCode.getText().trim().isEmpty() || postalCode.getText().trim().toLowerCase().equals("postal code")) {
                AlertMessage.error(1, postalCode);
                return;
            }

            Parent root = FXMLLoader.load(getClass().getResource("/view/SecondScreen.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 900, 500);
            stage.setTitle("Customer List");
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //get the data from customer table and transfer it to update to edit.
    public void pullCustomer(Customer customer) {
        customerID.setText(String.valueOf(customer.getCustomer_ID()));
        customerName.setText(customer.getCustomer_Name());
        address.setText(customer.getAddress());
        postalCode.setText(customer.getPostal_Code());
        phone.setText(customer.getPhone());
        Country cnty = CountryData.getCountryByDivision(customer.getDivisionID());
        countryCombo.setValue(cnty);

        //division depend on Country selection
        divisionCombo.setItems(DivisionData.getDivisionByCountry(cnty.getCountryId()));
        for (Division division : divisionCombo.getItems()) {
               if (division.getDivisionID() == customer.getDivisionID())
            {
                divisionCombo.setValue(division);
                break;
            }
        }
    }

//when country is selected, division will show what is linked to specific country.
    public void onCountryChange (ActionEvent actionEvent) {
        Country country = countryCombo.getValue();
        if(country != null) {
            divisionCombo.setItems(DivisionData.getDivisionByCountry(country.getCountryId()));
        }
    }
}