package controller;

/**
 * Appointment Update controller
 * @author Isabelle Matthews
 */

import Model.*;
import database.AppointmentData;
import database.ContactData;
import database.CustomerData;
import database.UserData;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AppointmentUpdate implements Initializable {
    public ComboBox<Contact> contactCombo;
    public ComboBox<Customer> customerCombo;
    public ComboBox<user> userCombo;
    public TextField appointmentID;
    public TextField title;
    public TextField description;
    public TextField type;
    public TextField start;
    public TextField end;
    public TextField location;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       contactCombo.setItems(ContactData.getAllContact());
        customerCombo.setItems(CustomerData.getAllCustomers());
        userCombo.setItems(UserData.getAllUsers());

    }

    //save APPOINTMENT
    public void saveButton(ActionEvent actionEvent) throws IOException {
        try {
            int appointment_ID = Integer.parseInt(appointmentID.getText());
            String Title = title.getText();
            String Description = description.getText();
            String Type = type.getText();
            String Location = location.getText();
            String Start = start.getText();
            String End = end.getText();
            int Contact_ID = (contactCombo.getValue().getContactID());
            int User_ID = (userCombo.getValue().getUserID());
            int Customer_ID = (customerCombo.getValue().getCustomer_ID());
            AppointmentData.updateAppointment(appointment_ID, Title, Description, Type, Location, Start, End, Contact_ID, User_ID, Customer_ID);

            if (title.getText().trim().isEmpty() || title.getText().trim().toLowerCase().equals("Title")) {
                AlertMessage.error(5, title);
                return;
            }
            if (description.getText().trim().isEmpty() || description.getText().trim().toLowerCase().equals("address")) {
                AlertMessage.error(6, description);
                return;
            }
            if (type.getText().trim().isEmpty() || type.getText().trim().toLowerCase().equals("phone")) {
                AlertMessage.error(7, type);
                return;
            }
            if (location.getText().trim().isEmpty() || location.getText().trim().toLowerCase().equals("postal code")) {
                AlertMessage.error(8,  location);
                return;
            }
            if (start.getText().trim().isEmpty() || start.getText().trim().toLowerCase().equals("postal code")) {
                AlertMessage.error(9, start);
                return;
            }
            if (end.getText().trim().isEmpty() || end.getText().trim().toLowerCase().equals("postal code")) {
                AlertMessage.error(10, end);
                return;
            }

            Parent root = FXMLLoader.load(getClass().getResource("/view/Scheduling.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root, 900, 500);
            stage.setTitle("Appointment");
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // get appointment from appointment table into update form.
    public void pullAppointment(Appointment appointment) {
        appointmentID.setText(String.valueOf(appointment.getAppointmentID()));
        title.setText(appointment.getTitle());
        description.setText(appointment.getDescription());
        type.setText(appointment.getType());
        location.setText(appointment.getLocation());
        start.setText(appointment.getStart().toString());
        end.setText(appointment.getEnd().toString());

        for (Contact contact : contactCombo.getItems()) {
            if (contact.getContactID() == appointment.getContactID())
            {
                contactCombo.setValue(contact);
            break;
        }
        }
        for (user use : userCombo.getItems()) {
            if (use.getUserID() == appointment.getUserID())
            {
                userCombo.setValue(use);
            break;
        }
        }
        for (Customer customer : customerCombo.getItems()) {
            if (customer.getCustomer_ID() == appointment.getCustomerID())
            {
                System.out.println("customer.getCustomer_ID =" +customer.getCustomer_ID() + " appointment.getAppointmentID="+appointment.getAppointmentID());
                   customerCombo.setValue(customer);
            break;
        }
        }
    }

    //cancel APPOINTMENT and go back to main screen
    public void cancelButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/Scheduling.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root, 900, 500);
        stage.setTitle("Appointment");
        stage.setScene(scene);
    }


}