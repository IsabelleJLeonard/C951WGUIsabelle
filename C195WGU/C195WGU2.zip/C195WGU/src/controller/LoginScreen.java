package controller;

/**
 * Login Screen Controller
 * @author Isabelle Matthews
 */

import database.UserData;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

public class LoginScreen implements Initializable {
    public TextField userText;
    public PasswordField passwordText;
    public Button logInBt;
    public Label login;
    public Label timeZone;
    public Label userID;
    public Label Password;
    ResourceBundle resourceBundle;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ResourceBundle myBundle = ResourceBundle.getBundle("language/language", Locale.getDefault());

        userID.setText(myBundle.getString("username"));
        Password.setText(myBundle.getString("password"));
        logInBt.setText(myBundle.getString("login"));
        login.setText(myBundle.getString("login"));

        ZoneId.systemDefault().toString();
        ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());
        System.out.println("timezone update" + localZoneId);
        timeZone.setText(ZoneId.systemDefault().toString());
    }

//log in button
    public void loginButton(ActionEvent actionEvent) throws IOException, SQLException {
        String username = userText.getText();
        String password = passwordText.getText();
        boolean valid = UserData.login(userText.getText(), passwordText.getText());
        if (valid) {
            ((Node) (actionEvent.getSource())).getScene().getWindow().hide();
            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/view/Main.fxml"));
            Scene scene = new Scene(root, 400, 400);
            stage.setScene(scene);
            stage.show();
        } else {
            ResourceBundle myBundle = ResourceBundle.getBundle("language/language", Locale.getDefault());
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(myBundle.getString("invalid"));
            alert.showAndWait();
        }
    }

     //TIME ZONE
    public void timeZone(ActionEvent actionEvent) {
        ZoneId.systemDefault().toString();
    }
}